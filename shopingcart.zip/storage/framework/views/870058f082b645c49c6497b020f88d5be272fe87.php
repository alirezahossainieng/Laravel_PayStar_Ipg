
<?php $__env->startSection('main'); ?>
<div class="card">
    <div class="card-header">
        <h4>product</h4>
        <?php if(session('message')): ?>
            <h6 class="text-center"><?php echo e(session('message')); ?></h6>
        <?php endif; ?>
    </div>
    <div class="card-body">
        <?php if($errors->any()): ?>
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <h6><?php echo e($error); ?></h6>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <form action="<?php echo e(route('product.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="title">title</label>
                    <input type="text" name="title" class="form-control">
                </div>
                
                <div class="col-md-6 mb-3">
                    <label for="image">image</label>
                    <input type="file" name="image" class="form-control">
                </div>
            
                
                <div class="col-md-6 mb-3">
                    <label for="price">price</label>
                    <input type="text" name="price" class="form-control">
                </div>
                
                <div class="col-md-6 mb-3">
                    <label for="body">body</label>
                    <textarea name="body" id="" cols="30" rows="4" class="form-control"></textarea>
                </div>
                <div class="col-md-6 mb-3">
                    <input type="submit" value="create" class="btn btn-primary">
                </div>
            </div>
        </form>
    </div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alireza\Desktop\shopingcart\resources\views/dashboard/product/create.blade.php ENDPATH**/ ?>