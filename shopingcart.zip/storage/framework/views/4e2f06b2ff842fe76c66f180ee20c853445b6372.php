
<?php $__env->startSection('main'); ?>
<div class="card">
    <div class="card-header">
        cart index
        <div class="col-3 ">
            <?php if(session('message')): ?>
            <h6 class="text-center bg-danger text-white"><?php echo e(session('message')); ?></h6>
        <?php endif; ?>
        </div>
    </div>
    <div class="card-body">
        <table class="table table-bordered table-striped  ">
            <tr>
                <td>num</td>
                <td>product</td>
                <td>qty</td>
                <td>count</td>
                <td>unitprice</td>
                <td>totalprice</td>
                <td>action</td>
                
            </tr>
            <?php $__currentLoopData = $cart->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key+1); ?></td>
                    <td><img src="<?php echo e(asset('assets/images/'.$item['product']->image)); ?>" alt="" width="220px"></td>
                    <td >
                        
                        <?php echo Form::open(['route'=>['updatecart',$item['product']->id] ,'method'=>'put']); ?>

                        <?php echo Form::text('qty', $value=$item['count'], ['class'=>'form-control']); ?>

                        
                            <?php echo Form::submit('update',['class'=>'btn btn-primary']); ?>

                            <?php echo Form::close(); ?>

                    </td>
                    <td><?php echo e($item['count']); ?></td>
                    <td><?php echo e($item['product']->price); ?></td>
                    <td><?php echo e($item['product']->price * $item['count']); ?></td>

                    
                    <td>
                        
                        <?php echo Form::open(['route'=>['removecart',$item['product']->id] ,'method'=>'delete']); ?>

                        <?php echo Form::submit('delete',['class'=>'btn btn-danger']); ?>

                        <?php echo Form::close(); ?>  
                        
                        
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <table class="table table-bordered table-striped  ">
            <tr>
                <td>total price</td>
                <td>count</td>
            </tr>
            <tr>
                <td><?php echo e($cart->price); ?></td>
                <td><?php echo e($cart->count); ?></td>
            </tr>
        </table>
        <?php echo Form::open(['route'=>'invoice' , 'method'=>'post']); ?>

        
        <?php echo Form::text('address', $value=$cart->address, ['class'=>'form-control']); ?>

      
        <?php echo Form::close(); ?>

        <a href="<?php echo e(route('orderstore')); ?>" class="btn btn-primary">next</a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alireza\Desktop\shopingcart\resources\views/website/cart/invoice.blade.php ENDPATH**/ ?>