
<?php $__env->startSection('main'); ?>
<div class="card">
    <div class="card-header">
        <h4>product</h4>
        <?php if(session('message')): ?>
            <h6 class="text-center"><?php echo e(session('message')); ?></h6>
        <?php endif; ?>
    </div>
    <div class="card-body">
        <?php if($errors->any()): ?>
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <h6><?php echo e($error); ?></h6>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        
        <?php echo Form::model($product, ['route' => ['product.update', $product->id],'method'=>'put','files'=>true]); ?>


            <div class="row">
                <div class="col-md-6 mb-3">
                    <?php echo Form::label('title', 'title'); ?>

                    <?php echo Form::text('title',$value=null, ['class' => 'form-control']); ?>

                </div>
                
                <div class="col-md-6 mb-3">
                    <?php echo Form::label('price', 'price'); ?>

                    <?php echo Form::text('price',$value=null, ['class' => 'form-control']); ?>

                </div>
                
               
                <div class="col-md-6 mb-3">
                    <?php echo Form::textarea('body', $value=null, ['class' => 'form-control']); ?>

                </div>
                
                <div class="col-md-6 mb-3">
                    <?php echo Form::label('image', 'image'); ?>

                    <?php echo Form::file('image', ['class'=>'form-control']); ?>

                </div>
                
                
                
                <div class="col-md-6 mb-3">
                    <?php echo Form::submit('update', ['class'=>'btn btn-primary']); ?>

                </div>
                <?php echo Form::close(); ?>

            </div>
               
            
        
    </div>
</div>


    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alireza\Desktop\shopingcart\resources\views/dashboard/product/edit.blade.php ENDPATH**/ ?>