<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/custom.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css">

    
    <?php echo $__env->yieldContent('css'); ?>
    <title>Document</title>
</head>
<body>
    <?php echo $__env->make('website.partials._header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('main'); ?>
    <script src="<?php echo e(asset('assets/js/jquery-3.6.0.min.js')); ?>"></script> 
    <script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>   
 <?php echo $__env->yieldContent('script'); ?>  
</body>
</html><?php /**PATH C:\Users\alireza\Desktop\shopingcart\resources\views/website/app.blade.php ENDPATH**/ ?>