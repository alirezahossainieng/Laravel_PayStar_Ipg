
<?php $__env->startSection('main'); ?>

<div class="product">
  <div class="header">
    <a href="<?php echo e(route('index.product')); ?>"><div class="back"></div>
    </div></a>
  <div class="main">
    <div class="left">
      <h1><?php echo e($product->title); ?></h1>
      <h2><?php echo e($product->body); ?></h2>
      
    </div>
    <div class="right mt-3 mb-3">
      <img src="<?php echo e(asset('assets/images/'.$product->image)); ?>" style="margin-bottom: 20px !important" />
      
      
      
      
    </div>
  </div>
  <div class="footer">
    <div class="left mt-3"><h3><?php echo e($product->price); ?>$</h3></div>
    <div class="right"> 
      
      <form action="<?php echo e(route('addproduct', ['product'=>$product->id])); ?>" method="post">
      <?php echo csrf_field(); ?>
      
      <input type="submit" value="add to cart" class="btn btn-primary">
    </form>
    </div>
  </div>
</div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alireza\Desktop\shopingcart\resources\views/website/product/show.blade.php ENDPATH**/ ?>