
<?php $__env->startSection('main'); ?>
<div class="card">
    <div class="card-header">
        cart index
        <div class="col-3 ">
            <?php if(session('message')): ?>
            <h6 class="text-center bg-danger text-white"><?php echo e(session('message')); ?></h6>
        <?php endif; ?>
        </div>
    </div>
    <div class="card-body">
       <h1>thancks for buying</h1>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alireza\Desktop\shopingcart\resources\views/website/cart/result.blade.php ENDPATH**/ ?>