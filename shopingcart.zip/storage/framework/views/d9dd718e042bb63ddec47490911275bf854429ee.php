
<?php $__env->startSection('main'); ?>
<div class="container text-center">
   <div class="row">
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-4 mt-4">
  <div class="card " style="width: 18rem;">
     <img src="<?php echo e(asset('assets/images/'.$product->image)); ?>" class="card-img-top indeximg" alt="...">
     <div class="card-body">
       <h5 class="card-title">Card title</h5>
       <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
       <hr>
       <div class="footer">
         <div class="left"><a href="<?php echo e(route('show.product',['id'=>$product->id])); ?>" class="btn btn-primary">detail</a>
         </div>
         
        
          <div class="right"><p><?php echo e($product->price); ?>$</p></div>
       </div>
       
     </div>
   </div>
 </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



     
    
   </div>
 </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alireza\Desktop\shopingcart\resources\views/website/product/index.blade.php ENDPATH**/ ?>