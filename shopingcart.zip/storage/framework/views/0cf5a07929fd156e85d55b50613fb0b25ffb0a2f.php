
<?php $__env->startSection('main'); ?>
<div class="card">
    <div class="card-header">
        product index
        <a href="<?php echo e(route('product.create')); ?>">add product</a>
        <?php if(session('message')): ?>
            <h6 class="text-center"><?php echo e(session('message')); ?></h6>
        <?php endif; ?>
    </div>
    <div class="caed-body">
        <table class="table table-bordered table-striped  ">
            <tr>
                <td>id</td>
                <td>title</td>
                <td>body</td>
                <td>price</td>
                <td>image</td>
                <td>action</td>
                
            </tr>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($product->id); ?></td>
                    <td><?php echo e($product->title); ?></td>
                    <td><?php echo e($product->body); ?></td>
                    <td><?php echo e($product->price); ?></td>
                    
                    <td><img src="<?php echo e(asset('assets/images/'.$product->image)); ?>" alt="" width="220px"></td>
                    
                    <td><a href="<?php echo e(route('product.edit', ['product'=>$product->id])); ?>" class="btn btn-primary">update</a> 
                        <?php echo Form::open(['route'=>['product.destroy',$product->id] ,'method'=>'delete']); ?>

                        <?php echo Form::submit('delete',['class'=>'btn btn-danger']); ?>

                        <?php echo Form::close(); ?>

                        
                        
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alireza\Desktop\shopingcart\resources\views/dashboard/product/index.blade.php ENDPATH**/ ?>